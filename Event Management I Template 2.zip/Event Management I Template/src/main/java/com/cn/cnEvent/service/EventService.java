package com.cn.cnEvent.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cn.cnEvent.dal.EventDAL;
import com.cn.cnEvent.entity.Event;

@Service
@Transactional
public class EventService {

	@Autowired
	EventDAL eventDAL;
	
	public Event getEventById(Long id) {
        return eventDAL.getById(id);
    }
	
	public List<Event> getAllEvents() {
        return eventDAL.getAllEvents();
    }
	
	public void saveEvent(Event event) {
        eventDAL.save(event);
    }
	
	public void deleteById(Long id) {
		eventDAL.delete(id);
	}
	
	public void updateEvent(Event updateEvent) {
		eventDAL.update(updateEvent);
	}
}
